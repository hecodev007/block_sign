# bifrost go sdk
    这个包其实和stafi-substrate-go包是一样的，主要区别是目前biforst和polkadot使用的address的类型是MultiAddress，其他的使用的是Address。
    后续如果其他的链使用MultiAddress都将转到这个包来。
## fork
    https://github.com/JFJun/stafi-substrate-go.git
## transfer
    交易请看./test/tx_test.go
    
