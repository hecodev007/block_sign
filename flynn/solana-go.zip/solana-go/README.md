# Solana go sdk
## fork
    https://github.com/solana-labs/solana-web3.js
## 功能
    仅提供solana链的本地签名，仅用于构建Transfer交易
 